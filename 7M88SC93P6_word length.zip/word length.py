a = input().split(" ")
print(len(a))